# Train Seat Booking Application (Java)
Programming 2 (Semester 2, 2017). Grade: A+

Each Train Operator has a different booking policy for when certain seats are booked out.

### Application Overview
![Welcome](/screenshots/welcome.png)
![Journey Selection](/screenshots/journey-selection.png)
![Seat Selection](/screenshots/seat-selection.png)
![Seat Confirmation](/screenshots/seat-confirmation.png)
